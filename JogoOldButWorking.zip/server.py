import socket
import pickle
import threading
import time
from Game import Game
from Player import Player
 
PORT = 5000
SERVER = socket.gethostbyname(socket.gethostname())
ADDRESS = (SERVER, PORT)

clients, names = [], []
 
server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(ADDRESS)
 

print('Starting game\n')
game = Game()

# function to start the connection
def startServer():
   
    print("server is working on " + SERVER)
     
    # listening for connections
    server.listen()
     
    while True:
       
        # accept connections and returns
        # a new connection to the client
        #  and  the address bound to it
        conn, addr =  server.accept()
        sendMsg(conn,{"NAME":''})

        name = pickle.loads(conn.recv(1024)).get('NAME')

        names.append(name)
        clients.append(conn)
        
        game.addPlayer(Player(conn, name))
         
        print(f"{addr} is :{name}")
         
        broadcastMessage(f"{name} has joined the game!")
         
        thread = threading.Thread(target = handleChat,
                                  args = (conn, addr))
        thread.start()
         
        # no. of clients connected
        # to the server
        print(f"active connections {len(clients)}")
 
def sendMsg(conn, msg):
    print(f'Sending message to client = {msg}\n') 
    conn.send(pickle.dumps(msg))

def broadcastMessage(message):
    message = {'CHAT': message}
    for client in clients:
        sendMsg(client,message)

def handleChat(conn, addr):
    connected = True
    while connected:
        msg = conn.recv(1024)
        print(msg)
        message = pickle.loads(msg)
        print(message)
        for key, value in message.items():
            if key == 'N_PLAYERS':
                game.numberOfPlayers = value
            elif key == 'CHAT':
                broadcastMessage(value)
            elif key == 'BET':
                game.setBetViaConn(conn,value)
            elif key == 'PICK':
                game.setPickViaConn(conn,value)
            else:
                print(key, value)
    conn.close()
 
def handleGame():
    while len(clients) == 0:
        time.sleep(1)
    sendMsg(clients[0], {"N_PLAYERS":''})
    while game.numberOfPlayers == 0:
        time.sleep(1)
    while game.numberOfPlayers != len(game.playersActived):
        sendMsg(clients[0], {"CHAT":'Waiting players'})
        time.sleep(3)
    game.run()

gameThread = threading.Thread(target = handleGame)
gameThread.start()
time.sleep(0.1)
startServer()
